<?php
declare(strict_types=1);

namespace App\Services;

use App\Helpers\Logger;

/**
 * Stock images: Unsplash primary, Pexels fallback.
 * Builds English visual queries so results match tech/howto topics (not random portraits).
 */
class ImageService
{
    public function isConfigured(): bool
    {
        return !empty($_ENV['UNSPLASH_ACCESS_KEY']) || !empty($_ENV['PEXELS_API_KEY']);
    }

    /**
     * @return list<array{url:string,alt:string,credit:string}>
     */
    public function search(string $query, int $count = 3, int $page = 1): array
    {
        $query = $this->normalizeQuery($query);
        if ($query === '') {
            return [];
        }

        $images = [];
        if (!empty($_ENV['UNSPLASH_ACCESS_KEY'])) {
            $images = $this->searchUnsplash($query, $count, $page);
        }
        if ($images === [] && !empty($_ENV['PEXELS_API_KEY'])) {
            $images = $this->searchPexels($query, $count, $page);
        }
        return $images;
    }

    /**
     * Diverse queries for random fallback search.
     */
    public function getRandomQueries(): array
    {
        return [
            'technology modern workspace laptop',
            'digital innovation computer desk',
            'creative workspace office technology',
            'online learning education laptop desk',
            'business productivity laptop workspace',
            'artificial intelligence future technology',
            'web development programming monitor',
            'digital marketing analytics laptop',
            'modern desk technology setup',
            'software development code screen',
            'cloud computing infrastructure data',
            'remote work computer desk setup',
        ];
    }

    public function injectIntoHtml(string $html, string $keyword, string $title = ''): string
    {
        if (!$this->isConfigured()) {
            return $html;
        }

        $queries = $this->buildQueryVariants($keyword, $title, $html);
        $images = [];
        foreach ($queries as $q) {
            $randPage = random_int(1, 3);
            $found = $this->search($q, 4 - count($images), $randPage);
            if ($found === [] && $randPage > 1) {
                $found = $this->search($q, 4 - count($images), 1);
            }
            foreach ($found as $img) {
                $images[] = $img;
                if (count($images) >= 4) {
                    break 2;
                }
            }
        }
        if ($images === []) {
            return $html;
        }

        // Remove any previous stock figures we injected (optional clean)
        $html = preg_replace('/<figure[^>]*>\s*<img[^>]+>\s*<figcaption[^>]*>Photo:.*?<\/figcaption>\s*<\/figure>/is', '', $html) ?? $html;

        $hero = array_shift($images);
        $heroBlock = $this->figureHtml($hero, true);

        // Every post must start directly with at least 2 substantive introductory paragraphs before the first image appears
        if (preg_match_all('/<\/p>/i', $html, $pMatches, PREG_OFFSET_CAPTURE)) {
            $targetP = count($pMatches[0]) >= 2 ? $pMatches[0][1] : $pMatches[0][0];
            $pos = $targetP[1] + strlen($targetP[0]);
            $html = substr($html, 0, $pos) . "\n" . $heroBlock . "\n" . substr($html, $pos);
        } else {
            $html = $html . "\n" . $heroBlock;
        }

        // Distribute remaining images evenly across the entire length of the article (from top to bottom)
        if ($images !== []) {
            preg_match_all('/<\/h2>/i', $html, $hMatches, PREG_OFFSET_CAPTURE);
            $totalHeadings = count($hMatches[0]);
            $totalImages = count($images);

            if ($totalHeadings > 0) {
                $targetIndices = [];
                if ($totalHeadings <= $totalImages) {
                    $targetIndices = range(0, $totalHeadings - 1);
                } else {
                    for ($i = 0; $i < $totalImages; $i++) {
                        $calcIdx = (int) round(($i + 1) * $totalHeadings / ($totalImages + 1)) - 1;
                        $calcIdx = max(0, min($totalHeadings - 1, $calcIdx));
                        if (!in_array($calcIdx, $targetIndices, true)) {
                            $targetIndices[] = $calcIdx;
                        }
                    }
                    sort($targetIndices);
                }

                $hCount = 0;
                $imgIdx = 0;
                $html = preg_replace_callback('/<\/h2>/i', function ($m) use (&$hCount, &$imgIdx, $targetIndices, $images) {
                    $currentH = $hCount++;
                    if (in_array($currentH, $targetIndices, true) && isset($images[$imgIdx])) {
                        $fig = $this->figureHtml($images[$imgIdx], false);
                        $imgIdx++;
                        return $m[0] . "\n" . $fig;
                    }
                    return $m[0];
                }, $html);
            }
        }

        return $html;
    }

    /**
     * Prefer English conceptual queries for stock photo APIs.
     */
    private function buildQueryVariants(string $keyword, string $title, string $html): array
    {
        $map = [
            'pdf' => 'pdf document laptop',
            'gemini' => 'artificial intelligence computer screen',
            'google' => 'google workspace laptop',
            'ai' => 'artificial intelligence technology',
            'summar' => 'document summary notes desk',
            'tutorial' => 'online learning laptop desk',
            'seo' => 'seo analytics dashboard',
            'marketing' => 'digital marketing laptop',
            'blog' => 'blogging writing laptop',
            'code' => 'programming code screen',
            'web' => 'web development computer',
            'mobile' => 'smartphone app development',
            'cloud' => 'cloud computing server',
            'data' => 'data analytics charts',
            'security' => 'cybersecurity lock computer',
            'email' => 'email inbox laptop',
            'social' => 'social media smartphone',
            'video' => 'video editing computer',
            'photo' => 'photography camera desk',
            'business' => 'business office laptop',
        ];

        $hay = mb_strtolower($keyword . ' ' . $title . ' ' . strip_tags(mb_substr($html, 0, 500)));
        $variants = [];
        foreach ($map as $needle => $q) {
            if (str_contains($hay, $needle)) {
                $variants[] = $q;
            }
        }

        // Latin words from keyword/title
        if (preg_match_all('/[A-Za-z]{3,}/', $keyword . ' ' . $title, $m)) {
            $words = array_unique(array_map('strtolower', $m[0]));
            $stop = ['the','and','for','with','from','that','this','your','how','what','when','pdf','html'];
            $words = array_values(array_filter($words, static fn($w) => !in_array($w, $stop, true)));
            if ($words !== []) {
                $variants[] = implode(' ', array_slice($words, 0, 4)) . ' technology laptop';
            }
        }

        if ($variants === []) {
            $pool = $this->getRandomQueries();
            $variants[] = $pool[array_rand($pool)];
            $variants[] = $pool[array_rand($pool)];
        }

        // Always avoid pure portrait searches
        $variants = array_map(static function ($q) {
            return trim($q . ' -portrait -face -person');
        }, $variants);

        return array_values(array_unique($variants));
    }

    private function normalizeQuery(string $query): string
    {
        $query = trim(preg_replace('/\s+/', ' ', $query) ?? '');
        // Unsplash ignores some operators; strip leading dashes mess
        $query = str_replace(['-portrait', '-face', '-person'], '', $query);
        $query = trim(preg_replace('/\s+/', ' ', $query) ?? '');
        return mb_substr($query, 0, 100);
    }

    private function figureHtml(array $img, bool $hero): string
    {
        $url = htmlspecialchars($img['url'], ENT_QUOTES, 'UTF-8');
        $alt = htmlspecialchars($img['alt'], ENT_QUOTES, 'UTF-8');
        $credit = htmlspecialchars($img['credit'], ENT_QUOTES, 'UTF-8');
        $style = 'margin:1.25rem 0;border-radius:8px;max-width:100%;height:auto;display:block;';
        return '<figure style="margin:1.25rem 0;">'
            . '<img src="' . $url . '" alt="' . $alt . '" style="' . $style . '" loading="lazy" />'
            . ($credit !== '' ? '<figcaption style="font-size:12px;color:#64748b;margin-top:4px;">Photo: ' . $credit . '</figcaption>' : '')
            . '</figure>';
    }

    private function searchPexels(string $query, int $count, int $page = 1): array
    {
        $url = 'https://api.pexels.com/v1/search?' . http_build_query([
            'query'       => $query,
            'per_page'    => max($count, 15),
            'page'        => $page,
            'orientation' => 'landscape',
        ]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_HTTPHEADER     => ['Authorization: ' . $_ENV['PEXELS_API_KEY']],
        ]);
        $raw = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300 || !is_string($raw)) {
            Logger::warning('Pexels search failed', ['code' => $code, 'query' => $query]);
            return [];
        }
        $data = json_decode($raw, true);
        $out = [];
        foreach (($data['photos'] ?? []) as $photo) {
            $alt = strtolower((string) ($photo['alt'] ?? ''));
            if ($this->looksLikePortrait($alt)) {
                continue;
            }
            $out[] = [
                'url'    => $photo['src']['large'] ?? $photo['src']['medium'] ?? '',
                'alt'    => $photo['alt'] ?? $query,
                'credit' => ($photo['photographer'] ?? 'Pexels') . ' / Pexels',
            ];
            if (count($out) >= $count) {
                break;
            }
        }
        if ($out !== []) {
            shuffle($out);
        }
        return array_values(array_filter($out, static fn($i) => $i['url'] !== ''));
    }

    private function searchUnsplash(string $query, int $count, int $page = 1): array
    {
        // Randomize order_by to avoid identical top-ranked list
        $orderBy = ($page % 2 === 0) ? 'latest' : 'relevant';
        $url = 'https://api.unsplash.com/search/photos?' . http_build_query([
            'query'          => $query,
            'per_page'       => max($count, 15),
            'page'           => $page,
            'order_by'       => $orderBy,
            'orientation'    => 'landscape',
            'content_filter' => 'high',
        ]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_HTTPHEADER     => [
                'Authorization: Client-ID ' . $_ENV['UNSPLASH_ACCESS_KEY'],
                'Accept-Version: v1',
            ],
        ]);
        $raw = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300 || !is_string($raw)) {
            Logger::warning('Unsplash search failed', ['code' => $code, 'query' => $query]);
            return [];
        }
        $data = json_decode($raw, true);
        $out = [];
        foreach (($data['results'] ?? []) as $photo) {
            $alt = strtolower((string) ($photo['alt_description'] ?? $photo['description'] ?? ''));
            if ($this->looksLikePortrait($alt)) {
                continue;
            }
            $out[] = [
                'url'    => $photo['urls']['regular'] ?? $photo['urls']['small'] ?? '',
                'alt'    => $photo['alt_description'] ?? $photo['description'] ?? $query,
                'credit' => (($photo['user']['name'] ?? 'Unsplash') . ' / Unsplash'),
            ];
            if (count($out) >= $count) {
                break;
            }
        }
        if ($out !== []) {
            shuffle($out);
        }
        return array_values(array_filter($out, static fn($i) => $i['url'] !== ''));
    }

    private function looksLikePortrait(string $alt): bool
    {
        foreach (['portrait', 'man smiling', 'woman smiling', 'face of', 'headshot', 'selfie'] as $bad) {
            if (str_contains($alt, $bad)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Replace images in HTML.
     *
     * @param string        $html
     * @param string        $query         search keyword (can be empty or 'RANDOM')
     * @param string        $mode          'all' | 'index' | 'indexes'
     * @param int|null      $index         0-based when mode=index
     * @param int[]         $indexes       0-based list when mode=indexes
     * @param bool          $isRandomQuery If true, force pick a random conceptual query
     * @return array{html: string, changed: int, images: array, query_used: string}
     */
    public function replaceImagesInHtml(
        string $html,
        string $query         = '',
        string $mode          = 'all',
        ?int   $index         = null,
        array  $indexes       = [],
        bool   $isRandomQuery = false
    ): array {
        if (!$this->isConfigured()) {
            throw new \RuntimeException('Image API not configured (Unsplash/Pexels keys missing).');
        }

        // Random query handling
        $randomPool = $this->getRandomQueries();
        if ($isRandomQuery || strtoupper(trim($query)) === 'RANDOM' || trim($query) === '') {
            $query = $randomPool[array_rand($randomPool)];
        }

        preg_match_all('/<img\b[^>]*>/i', $html, $matches, PREG_OFFSET_CAPTURE);
        $imgs = $matches[0] ?? [];
        if ($imgs === []) {
            return ['html' => $html, 'changed' => 0, 'images' => [], 'query_used' => $query];
        }

        $intIndexes = array_map('intval', $indexes);
        $targetCount = match ($mode) {
            'index'   => 1,
            'indexes' => count($intIndexes),
            default   => count($imgs),
        };

        // Random page (1-5) to fetch fresh, different images
        $randomPage = random_int(1, 5);
        $found = $this->search($query, max($targetCount + 4, 10), $randomPage);

        // Fallback to page 1 if page > 1 had no results
        if ($found === [] && $randomPage > 1) {
            $found = $this->search($query, max($targetCount + 4, 10), 1);
        }

        // If still nothing, try a generic random query
        if ($found === []) {
            $fallbackQ = $randomPool[array_rand($randomPool)];
            $found = $this->search($fallbackQ, max($targetCount + 4, 10), 1);
            if ($found !== []) {
                $query = $fallbackQ;
            }
        }

        if ($found === []) {
            throw new \RuntimeException('No stock images found for query: ' . $query);
        }

        // Shuffle so we get diverse selections
        shuffle($found);

        $changed = 0;
        $used    = [];

        // Replace from end backwards so byte offsets stay exact
        for ($i = count($imgs) - 1; $i >= 0; $i--) {
            if ($mode === 'index'   && $index !== null && $i !== (int)$index) {
                continue;
            }
            if ($mode === 'indexes' && !in_array($i, $intIndexes, true)) {
                continue;
            }

            $imgTag    = $imgs[$i][0];
            $pos       = $imgs[$i][1];
            $pick      = $found[$changed % count($found)];
            $newSrc    = $pick['url'];
            $newAlt    = htmlspecialchars($pick['alt'] ?? $query, ENT_QUOTES, 'UTF-8');
            $newCredit = htmlspecialchars($pick['credit'] ?? '', ENT_QUOTES, 'UTF-8');

            $newTag = preg_replace('/\ssrc=(["\'])(.*?)\1/i', ' src="' . htmlspecialchars($newSrc, ENT_QUOTES, 'UTF-8') . '"', $imgTag, 1);
            if ($newTag === null || $newTag === $imgTag) {
                $newTag = preg_replace('/<img\b/i', '<img src="' . htmlspecialchars($newSrc, ENT_QUOTES, 'UTF-8') . '"', $imgTag, 1) ?? $imgTag;
            }
            $newTag = preg_replace('/\salt=(["\'])(.*?)\1/i', ' alt="' . $newAlt . '"', $newTag, 1) ?? $newTag;

            // Check if there is a figcaption right after this img tag
            $afterImg = substr($html, $pos + strlen($imgTag));
            if ($newCredit !== '' && preg_match('/^(\s*<figcaption[^>]*>)(?:Photo:\s*)?(.*?)(<\/figcaption>)/is', $afterImg, $fcm)) {
                $figFull = $fcm[0];
                $figReplacement = $fcm[1] . 'Photo: ' . $newCredit . $fcm[3];
                $html = substr($html, 0, $pos) . $newTag . $figReplacement . substr($afterImg, strlen($figFull));
            } else {
                $html = substr($html, 0, $pos) . $newTag . $afterImg;
            }

            $used[]  = $pick;
            $changed++;

            if ($mode === 'index') {
                break;
            }
        }

        return [
            'html'       => $html,
            'changed'    => $changed,
            'images'     => array_reverse($used),
            'query_used' => $query,
        ];
    }

    /**
     * List all images in HTML with index, 1-based number, src, alt, credit
     * @return list<array{index:int, number:int, src:string, alt:string, credit:string}>
     */
    public function listImageSrcsIndexed(string $html): array
    {
        preg_match_all('/<img\b[^>]*>/i', $html, $matches, PREG_OFFSET_CAPTURE);
        $out = [];
        foreach ($matches[0] ?? [] as $i => [$tag, $pos]) {
            $src = '';
            $alt = '';
            if (preg_match('/\ssrc=(["\'])(.*?)\1/i', $tag, $sm)) {
                $src = $sm[2];
            }
            if (preg_match('/\salt=(["\'])(.*?)\1/i', $tag, $am)) {
                $alt = $am[2];
            }

            $credit = '';
            $tail = substr($html, $pos + strlen($tag), 300);
            if (preg_match('/<figcaption[^>]*>(?:Photo:\s*)?(.*?)<\/figcaption>/is', $tail, $cm)) {
                $credit = strip_tags($cm[1]);
            }

            $out[] = [
                'index'  => $i,
                'number' => $i + 1,
                'src'    => $src,
                'alt'    => $alt,
                'credit' => $credit,
            ];
        }
        return $out;
    }

    /** List image srcs in HTML */
    public function listImageSrcs(string $html): array
    {
        preg_match_all('/<img\b[^>]*\ssrc=(["\'])(.*?)\1[^>]*>/i', $html, $m);
        return $m[2] ?? [];
    }
}
