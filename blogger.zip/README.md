# AI Blog Generator & Blogger Auto Publisher

Production-ready PHP 8.2 application for AI blog generation, review, human approval, and auto-publish to Google Blogger.

## Workflow

```
Topic → AI Generation → AI Review → Human Review → Approve → Schedule → Cron → Blogger API → Published
```

Human approval is **mandatory**. AI never publishes on its own.

## Project Structure

```
ai-blogger/
├── index.php              ← Front controller (document root)
├── .htaccess              ← URL rewrite + security
├── .env.example
├── .env                   ← Create from .env.example (not in git)
├── README.md
│
├── app/
│   ├── Controllers/       ← Auth, Dashboard, Post, Blogger, Settings
│   ├── Models/            ← Database models
│   ├── Services/          ← AI, Blogger, Scheduler
│   │   └── AI/            ← Gemini, OpenRouter, Groq, Cloudflare
│   ├── Middleware/        ← Auth, Guest, CSRF
│   ├── Helpers/           ← Router, DB, Session, Csrf, etc.
│   └── Views/             ← PHP templates (layouts, auth, posts…)
│
├── assets/
│   └── js/app.js          ← Frontend JS
│
├── config/
│   ├── app.php
│   └── database.php
│
├── routes/web.php
├── database/
│   ├── migrations/
│   └── seeders/
├── cron/
│   ├── process_scheduler.php
│   ├── retry_failed_posts.php
│   └── cleanup_logs.php
└── storage/
    ├── logs/
    └── cache/
```

## Requirements

- PHP 8.2+
- MySQL 8.0+
- Extensions: curl, pdo_mysql, openssl, mbstring, json
- Apache with `mod_rewrite` (or Nginx equivalent)
- Cron access

## Installation

### 1. Upload / extract

Point your web server **document root** to this project folder (where `index.php` lives).

### 2. Environment

```bash
cp .env.example .env
nano .env
```

Set at least:

```env
APP_URL=https://yourdomain.com
DB_HOST=127.0.0.1
DB_DATABASE=ai_blogger
DB_USERNAME=...
DB_PASSWORD=...
APP_TIMEZONE=Asia/Dhaka
```

### 3. Database

```bash
mysql -u root -p -e "CREATE DATABASE ai_blogger CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p ai_blogger < database/migrations/001_create_tables.sql
php database/seeders/seed.php
```

Default login: **admin@example.com** / **Admin@12345**  
Change this password after first login.

### 4. Permissions

```bash
chmod -R 755 storage
chown -R www-data:www-data storage
```

### 5. Apache VirtualHost example

```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    DocumentRoot /var/www/ai-blogger

    <Directory /var/www/ai-blogger>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

### 6. Nginx example

```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /var/www/ai-blogger;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ ^/(app|config|database|cron|storage|routes)/ {
        deny all;
    }
}
```

## AI Providers (at least one)

Priority: Gemini → OpenRouter → Groq → Cloudflare

```env
GEMINI_API_KEY=
GEMINI_MODEL=gemini-1.5-flash

OPENROUTER_API_KEY=
OPENROUTER_MODEL=google/gemini-flash-1.5

GROQ_API_KEY=
GROQ_MODEL=llama-3.3-70b-versatile

CLOUDFLARE_ACCOUNT_ID=
CLOUDFLARE_API_TOKEN=
CLOUDFLARE_MODEL=@cf/meta/llama-3.1-8b-instruct
```

## Google OAuth + Blogger

1. [Google Cloud Console](https://console.cloud.google.com/) → enable **Blogger API v3**
2. Create OAuth 2.0 Client (Web)
3. Redirect URI: `https://yourdomain.com/auth/google/callback`
4. Put credentials in `.env`:

```env
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI=https://yourdomain.com/auth/google/callback
BLOGGER_BLOG_ID=
```

5. Admin panel → **Blogger** → **Connect Blogger**

## Cron Jobs

```cron
*/5 * * * * php /var/www/ai-blogger/cron/process_scheduler.php >> /var/www/ai-blogger/storage/logs/cron.log 2>&1
*/15 * * * * php /var/www/ai-blogger/cron/retry_failed_posts.php >> /var/www/ai-blogger/storage/logs/cron.log 2>&1
0 3 * * * php /var/www/ai-blogger/cron/cleanup_logs.php >> /var/www/ai-blogger/storage/logs/cron.log 2>&1
```

## Security

- PDO prepared statements
- CSRF on all POST actions
- HTML sanitization
- Login rate limiting + lockout
- Sensitive folders blocked via `.htaccess`
- API keys only in `.env` (never in frontend)

## Production checklist

- [ ] `APP_DEBUG=false`
- [ ] Strong DB password + changed admin password
- [ ] HTTPS + `SESSION_SECURE=true`
- [ ] At least one AI API key
- [ ] Blogger connected
- [ ] Cron jobs installed
- [ ] `storage/` writable, not publicly listable
